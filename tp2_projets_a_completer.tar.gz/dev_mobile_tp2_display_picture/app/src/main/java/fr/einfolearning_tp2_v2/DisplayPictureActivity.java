package fr.einfolearning_tp2_v2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

/**
 * Auteur : B. LEMAIRE
 * Reproduction interdite
 * Version 2023
 */



public class DisplayPictureActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_picture);


        // A compléter


    }
}
